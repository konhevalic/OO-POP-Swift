import UIKit

protocol Passaro: CustomStringConvertible {
    var nome: String { get }
    var podeVoar: Bool { get }
    
}

protocol Voador {
    var velocidadeMaxima: Double { get }
}

extension Passaro {
    var podeVoar: Bool {
        self is Voador
    }
}

extension CustomStringConvertible where Self: Passaro {
    
    var description: String {
        podeVoar ? "Pode voar" : "Nao pode voar"
    }
}


struct Papagaio: Passaro, Voador {
    
    let nome: String
    let amplitude: Double
    let frequencia: Double
    
    var velocidadeMaxima: Double { 3 * amplitude * frequencia }
    
}

let papagaio = Papagaio(nome: "Parrot", amplitude: 12.0, frequencia: 60.0)

print(papagaio)

//se o pinguim implementa Voador, deve adicionar velocidadeMaxima em seus parametros
//caso queira imprimir uma frase dizendo que nao voa junto com o nome, precisa implementar uma variavel
struct Pinguim: Passaro {
    let nome: String
    //var velocidadeMaxima: Double
    
    //var podeVoar: Bool
    
}

//let pinguim = Pinguim(nome: "Pingo", velocidadeMaxima: 3)
let pinguim = Pinguim(nome: "Pingo")
print(pinguim)



struct Pombo: Passaro, Voador {
    let nome: String
    let amplitude: Double
    let frequencia: Double
    
    var velocidadeMaxima: Double {
        
        3 * amplitude * frequencia
    }
}

struct Avestruz: Passaro {
    let nome: String
}

let pombo = Pombo(nome: "Pru", amplitude: 14.0, frequencia: 12.0)
print(pombo)

let avestruz = Avestruz(nome: "Avestrid")
print(avestruz)

enum Andorinha: Passaro, Voador {
    case africano
    case europeu
    case unknown
    
    var nome: String {
        switch self {
            case .africano:
                return "Ando Africana"
            case .europeu:
                return "Ando europeia"
            case .unknown:
                return "Apenas ando"
        }
    }
    
    var velocidadeMaxima: Double {
        switch self {
        case .africano:
            return 10.0
        case .europeu:
            return 3.5
        case .unknown:
            fatalError("Nao sabemos a velocidade")
        }
    }
}

extension Andorinha {
    var podeVoar: Bool {
        self != .unknown
    }
}

Andorinha.unknown
Andorinha.africano

let andor = Andorinha.europeu


print(Andorinha.africano,  "andorinha")

class Moot {
    var nome: String
    var velocidae: Double
    
    init(nome: String) {
        self.nome = nome
        velocidae = 200.0
    }
}

protocol Corrida {
    var velocidae: Double { get }
}

extension Papagaio: Corrida {
    var velocidae: Double {
        velocidadeMaxima
    }
}

extension Pinguim: Corrida {
    var velocidae: Double {
        42
    }
}

extension Andorinha: Corrida {
    var velocidae: Double {
        podeVoar ? velocidadeMaxima : 0.0
    }
}

extension Moot: Corrida {}

//criacao de um array de qualquer tipo de objeto/classe que esteja conforme o protocolo Corrida
let corredores: [Corrida] = [
    Andorinha.africano,
    Andorinha.europeu,
    Andorinha.unknown,
    Pinguim(nome: "Pingo"),
    Papagaio(nome: "Papa", amplitude: 4.0, frequencia: 12.5),
    Moot(nome: "Alan")
]

func velocidadeMaisAlta(of corredores: [Corrida]) -> Double {
    corredores.max(by: {$0.velocidae < $1.velocidae})?.velocidae ?? 00
}

print("Velocidade maxima dos pilotos foi de \(velocidadeMaisAlta(of: corredores))")

extension Sequence where Iterator.Element == Corrida {
    
    func velocidadeMaisAlta() -> Double {
        self.max(by: {$0.velocidae < $1.velocidae})?.velocidae ?? 00
    }
}

print("Velocidade utilizando sequence: \(corredores.velocidadeMaisAlta())")
print("Velocidade entre os 3 primeiros utilizando sequence: \(corredores[1...3].velocidadeMaisAlta())")


protocol Cheat {
    mutating func boost(_ power: Double)
}

struct FlappyBird: Passaro, Voador {
    var nome: String { "Flappy \(version)"}
    let version: Double
    private var fatorVelocidade = 1000.0
    
    init(version: Double) {
        self.version = version
    }
    
    var velocidadeMaxima: Double {
        version * fatorVelocidade
    }
}

extension FlappyBird: Cheat {
    mutating func boost(_ power: Double) {
        fatorVelocidade += power
    }
}

var flappy = FlappyBird(version: 5.0)
flappy.boost(3)
print(flappy.velocidadeMaxima, flappy.nome)
