import UIKit

class ComportamentoPessoa {
    var idade: Int!
    var genero: String!
    var cor: String!
    var  estadoCivil: String!
    
    func praticaEsporte(esporte: String) {
        //
    }
}


class Parede{
    let largura: Double
    let altura: Double
    
    init(largura: Double, altura: Double) {
        self.largura = largura
        self.altura = altura
    }
    
    func calculaArea() -> Double {
        return altura * largura
    }
}

let parede = Parede(largura: 3.0, altura: 5.0)

parede.calculaArea()

class Universidade {
    var nome: String
    var rank: String
    
    //inicializador primario
    init(nome: String, rank: String) {
        self.nome = nome
        self.rank = rank
    }
    
    //inicializador de conveniencia, utiliza-se para criar valores padrao
    convenience init() {
        self.init(nome: "UFPR", rank: "1")
    }
}

let universidade = Universidade()
print(universidade.nome)

class Arquivo {
    var pasta: String
    
    //inicilizador opcional
    init?(pasta: String) {
        if pasta.isEmpty {
            print("Pasta nao encontrada")
            return nil
        }
        self.pasta = pasta
    }
}

var arquivo = Arquivo(pasta: "F")
if arquivo != nil {
    print("arquivo encontrado")
} else {
    print("arquivo n encontrado")
}

struct PessoaStruct {
    var nome: String
    var idade: Int
    
}

var pessoaStruct = PessoaStruct(nome: "Alan", idade: 26)
print(pessoaStruct.nome)


//ENCAPSULAMENTO====================================
class Matematica {
    private var resultado: Int?
    private let a: Int
    private let b: Int
    
    init(a: Int, b: Int) {
        self.a = a
        self.b = b
    }
    
    func add() {
        resultado = a + b
    }
    
    func mostrarResultado() {
        print("Resultado: \(resultado ?? 0)")
    }
}

let calcular = Matematica(a: 5, b: 3)
calcular.add()
calcular.mostrarResultado()

//permite q seja herdado e q o comportamento seja alterado
open class ClasseOpen {
    open var idade: Int = 10
    
    open func jogo(esporte: String) {
        
    }
}

//nao permite q seja herdado e q o comportamento seja alterado.
//pode ser utilizada fora do modulo
public class ClassePublica {
    public var idade: Int = 3
    
    public func joga(esporte: String) {
        
    }
}

//acesso interno. pode ser utilizada apenas dentro do modulo
internal class ClasseInterna {
    internal var idade: Int = 15
    
    internal func joga(esporte: String) {
        
    }
}

//a classe pode ser utilizada dentro do arquivo que foi definida
fileprivate class ClasseFilePrivate {
    fileprivate var idade: Int = 25
    fileprivate func joga(esporte: String) {
        
    }
}

private class ClassePrivate {
    private var idade: Int = 24
    private func joga(esporte: String) {
        
    }
}

//HERANCA=============================================
class Pessoa {
    var idade: Int
    var genero: String
    var cor: String
    var estadoCivil: String
    
    init(idade: Int, genero: String, cor: String, estadoCivil: String) {
        self.idade = idade
        self.genero = genero
        self.cor = cor
        self.estadoCivil = estadoCivil
    }
    
    func praticaEsporte(esporte: String) {
        print( "Esporte praticado: \(esporte)")
    }
}

class Homem: Pessoa {
     
}

let alan = Homem(idade: 26, genero: "Masculino", cor: "Branco", estadoCivil: "Solteiro")

class JogadorFutebol: Pessoa {
    
    override func praticaEsporte(esporte: String) {
        print("Jogador de \(esporte)")
    }
}

let jogador = JogadorFutebol(idade: 30, genero: "Feminino", cor: "Branca", estadoCivil: "Solteira")

jogador.praticaEsporte(esporte: "futebol")


//POLIMORFISMO============================
class Jogador {
    let name: String
    
    init(name:String) {
        self.name = name
    }
    
    func play() {
        print("Comportamento padrao")
    }
    
}

class Batedor: Jogador {
    override func play() {
        bater()
    }
    
    private func bater() {
        print("\(name) esta rebatendo")
    }
}



